<!-- Title -->
<title>Access Denied - Online Biblioteka</title>
<!-- Icon -->
<link rel="shortcut icon" href="{{asset('img/library-favicon.ico')}}" type="image/vnd.microsoft.icon" />
<!-- Meta -->
<x-meta></x-meta>
<!-- Style -->
<link rel="stylesheet" href="{{asset('maintenance/style/access_denied.css')}}">

<div class="container">
    <h1>4<div class="lock"><div class="top"></div><div class="bottom"></div>
      </div>3</h1><p>Access denied</p>
  </div>

  
<script src="{{asset('maintenance/js/access_denied.js')}}"></script>