<!-- Title -->
<title>Pristup odbijen - Online Biblioteka</title>
<!-- Icon -->
<link rel="icon" type="image/x-icon" href="{{asset('library-favicon.ico')}}">
<!-- Meta -->
<x-meta></x-meta>
<!-- Style -->
<link rel="stylesheet" href="{{asset('maintenance/style/access_denied.css')}}">

<div class="container">
    <h1>4<div class="lock"><div class="top"></div><div class="bottom"></div>
      </div>3</h1><p>Pristup odbijen</p>
  </div>

  
<script src="{{asset('maintenance/js/access_denied.js')}}"></script>