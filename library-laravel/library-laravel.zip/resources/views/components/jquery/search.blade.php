{{-- Search functionality --}}
<script src="{{asset('/js/search-jquery.js')}}"></script>