{{-- JQuery CDN --}}
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" referrerpolicy="no-referrer"></script>
{{-- Session message fade out js file --}}
<script src="{{asset('js/session_message_jquery.js')}}"></script>


