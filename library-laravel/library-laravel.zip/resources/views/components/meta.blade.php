<!-- Meta -->
<meta charset="UTF-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
<meta http-equiv="content-language" content="en" />
<meta name="author" content="nullable()" />
<meta name="description" content="ICT Cortex Library - project for high school students..." />
<meta name="keywords" content="ict cortex, cortex, coinis, highschool, students, coding" />
<meta name="theme-color" content="#D22336">
<!-- End Meta -->
