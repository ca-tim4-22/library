<!-- Title -->
<title>Operacija uspješna | Online Biblioteka</title>
<!-- Meta -->
<x-meta></x-meta>
<div class="photo">
    <img 
    width="500"
    height="auto"
    src="https://static.vecteezy.com/system/resources/previews/005/266/445/original/successfully-deleted-concept-illustration-flat-design-eps10-modern-graphic-element-for-landing-page-empty-state-ui-infographic-icon-vector.jpg">
</div>
<style>
.photo {
    position:relative;
    height: 100%;
    width:100%;
}

img {
    position:absolute;
    top:0;
    left:0;
    right:0;
    bottom:0;
    margin:auto;
}
</style>